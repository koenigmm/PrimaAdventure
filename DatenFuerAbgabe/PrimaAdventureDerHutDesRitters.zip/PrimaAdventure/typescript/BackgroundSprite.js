"use strict";
var PrimaAdventure;
(function (PrimaAdventure) {
    class BackgroundSprite extends PrimaAdventure.SimpleSprite {
        constructor(_img, _scaling, _position) {
            super(_img, _scaling, _position);
        }
    }
    PrimaAdventure.BackgroundSprite = BackgroundSprite;
})(PrimaAdventure || (PrimaAdventure = {}));
//# sourceMappingURL=BackgroundSprite.js.map